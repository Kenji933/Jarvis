package com.voidmusic.app.model

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrackTest {
    private fun track(allowed: Boolean, downloadUrl: String) = Track(
        id = "track-1", title = "Test Track", artist = "Test Artist", album = "Test Album",
        imageUrl = "", streamUrl = "https://example.invalid/stream", downloadUrl = downloadUrl,
        downloadAllowed = allowed, licenseName = "Creative Commons", licenseUrl = "https://creativecommons.org/licenses/by/4.0/",
        durationSeconds = 120
    )

    @Test fun explicitJamendoPermissionAndUrlAllowDownload() {
        assertTrue(track(allowed = true, downloadUrl = "https://example.invalid/download").canDownload)
    }

    @Test fun deniedJamendoPermissionAlwaysBlocksDownload() {
        assertFalse(track(allowed = false, downloadUrl = "https://example.invalid/download").canDownload)
    }

    @Test fun missingDownloadUrlBlocksDownloadEvenWhenFlagIsTrue() {
        assertFalse(track(allowed = true, downloadUrl = "").canDownload)
    }

    @Test fun creativeCommonsLicenseIsRecognizedAsFreeLicensed() {
        assertTrue(track(allowed = false, downloadUrl = "").hasFreeLicense)
    }

    @Test fun nonCreativeCommonsCatalogLicenseIsNotIncluded() {
        val restricted = track(allowed = false, downloadUrl = "").copy(licenseName = "Jamendo Pro", licenseUrl = "https://licensing.jamendo.com/")
        assertFalse(restricted.hasFreeLicense)
    }
}
