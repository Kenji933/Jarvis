package com.voidmusic.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SkipNext
import androidx.compose.material.icons.outlined.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class AppScreen { HOME, SEARCH, RECOGNIZE, LIBRARY, SETTINGS, PLAYER }

@Composable
fun VoidMusicApp(model: MusicViewModel, requestRecognition: () -> Unit) {
    var screen by remember { mutableStateOf(AppScreen.HOME) }
    VoidTheme(model.darkTheme.value) {
        Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
            if (screen == AppScreen.PLAYER) {
                PlayerScreen(model = model, onBack = { screen = AppScreen.HOME })
            } else {
                Box(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize()) {
                        TopBar(screen = screen, onBack = { screen = AppScreen.HOME })
                        Crossfade(targetState = screen, label = "screen", modifier = Modifier.weight(1f)) { target ->
                            when (target) {
                                AppScreen.HOME -> HomeScreen(model, onPlay = { model.play(it, model.tracks.value) }, onMood = model::browseMood)
                                AppScreen.SEARCH -> SearchScreen(model, onPlay = { model.play(it, model.tracks.value) }, onMood = model::browseMood)
                                AppScreen.RECOGNIZE -> RecognizeScreen(model, requestRecognition)
                                AppScreen.LIBRARY -> LibraryScreen(model, onPlay = { model.play(it, model.likedTracks.value + model.recentTracks.value) })
                                AppScreen.SETTINGS -> SettingsScreen(model)
                                AppScreen.PLAYER -> Unit
                            }
                        }
                        Spacer(Modifier.height(145.dp))
                    }
                    Column(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, MaterialTheme.colorScheme.background.copy(alpha = .96f), MaterialTheme.colorScheme.background)))
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .padding(start = 16.dp, end = 16.dp, bottom = 8.dp, top = 18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        MiniPlayer(model, onOpen = { screen = AppScreen.PLAYER })
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            NavigationPill(Modifier.weight(1f), screen = screen, onNavigate = { screen = it })
                            Spacer(Modifier.width(10.dp))
                            Surface(
                                modifier = Modifier.size(54.dp).clickable { screen = AppScreen.SETTINGS },
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surface.copy(alpha = .94f),
                                tonalElevation = 4.dp,
                                shadowElevation = 10.dp
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Outlined.MoreHoriz, contentDescription = "More and settings", tint = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopBar(screen: AppScreen, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Brush.linearGradient(listOf(VoidLilac, VoidGlow))), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.GraphicEq, contentDescription = null, tint = Color(0xFF171120), modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text("VOID MUSIC", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black, letterSpacing = 2.1.sp)
                Text(if (screen == AppScreen.HOME) "A quieter kind of loud" else screen.name.lowercase().replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text("∞", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleLarge, modifier = Modifier.clickable { onBack() })
    }
}

@Composable
private fun MiniPlayer(model: MusicViewModel, onOpen: () -> Unit) {
    val track = model.currentTrack.value ?: model.tracks.value.firstOrNull()
    if (track == null) return
    val transition = rememberInfiniteTransition(label = "record-spin")
    val rotation by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(7_000, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "rotation"
    )
    Surface(
        modifier = Modifier.fillMaxWidth().clickable { onOpen() }.border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .2f), RoundedCornerShape(26.dp)),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .96f), shape = RoundedCornerShape(26.dp), tonalElevation = 6.dp, shadowElevation = 14.dp
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumDisc(track, Modifier.size(42.dp).rotate(if (model.isPlaying.value) rotation else 0f))
            Column(Modifier.weight(1f).clickable { onOpen() }.padding(start = 11.dp)) {
                Text(track.title, maxLines = 1, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                Text(track.artist, maxLines = 1, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Outlined.SkipPrevious, "Previous", Modifier.size(30.dp).clickable { model.previous() }, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Icon(if (model.isPlaying.value) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, "Play or pause", Modifier.size(34.dp).clickable { model.togglePlayback() }, tint = MaterialTheme.colorScheme.primary)
            Icon(Icons.Outlined.SkipNext, "Next", Modifier.size(30.dp).clickable { model.next() }, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun NavigationPill(modifier: Modifier, screen: AppScreen, onNavigate: (AppScreen) -> Unit) {
    Surface(
        shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .96f),
        tonalElevation = 5.dp, shadowElevation = 10.dp, modifier = modifier.height(54.dp)
    ) {
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
            NavItem("Home", Icons.Outlined.Home, screen == AppScreen.HOME) { onNavigate(AppScreen.HOME) }
            NavItem("Search", Icons.Outlined.Search, screen == AppScreen.SEARCH) { onNavigate(AppScreen.SEARCH) }
            NavItem("Recognize", Icons.Outlined.GraphicEq, screen == AppScreen.RECOGNIZE) { onNavigate(AppScreen.RECOGNIZE) }
            NavItem("Library", Icons.Outlined.LibraryMusic, screen == AppScreen.LIBRARY) { onNavigate(AppScreen.LIBRARY) }
        }
    }
}

@Composable
private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(18.dp)).clickable { onClick() }.padding(horizontal = 8.dp, vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = label, tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(19.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}
