package com.voidmusic.app.data

import android.content.Context
import com.voidmusic.app.BuildConfig
import com.voidmusic.app.model.Track
import kotlinx.coroutines.flow.map

class MusicRepository(context: Context) {
    private val dao = MusicDatabase.get(context).trackDao()
    private val downloads = TrackDownloads(context)
    val liked = dao.liked().map { rows -> rows.map(TrackEntity::toTrack) }
    val downloaded = dao.downloaded().map { rows -> rows.map(TrackEntity::toTrack) }
    val recent = dao.recentlyPlayed().map { rows -> rows.map(TrackEntity::toTrack) }

    suspend fun search(query: String = "", tags: String? = null): List<Track> {
        check(BuildConfig.JAMENDO_CLIENT_ID.isNotBlank()) {
            "Add your Jamendo client ID to local.properties to browse music."
        }
        val response = JamendoApi.service.tracks(JamendoApi.params(query, tags))
        if (response.headers?.status != "success") {
            throw IllegalStateException(response.headers?.error_message ?: "Jamendo could not load music.")
        }
        return response.results.map(JamendoTrack::toDomain)
            .filter { it.streamUrl.isNotBlank() && it.hasFreeLicense }
    }

    suspend fun toggleLike(track: Track) {
        val saved = dao.find(track.id)
        val wasLiked = saved?.liked == true
        dao.put(TrackEntity.from(track, liked = !wasLiked, localPath = saved?.localPath, playedAt = saved?.lastPlayedAt ?: 0L))
    }

    suspend fun isLiked(id: String) = dao.find(id)?.liked == true

    suspend fun markPlayed(track: Track) {
        val saved = dao.find(track.id)
        dao.put(TrackEntity.from(track, liked = saved?.liked == true,
            localPath = saved?.localPath ?: track.localPath, playedAt = System.currentTimeMillis()))
    }

    suspend fun download(track: Track): Track {
        val file = downloads.download(track)
        val saved = dao.find(track.id)
        dao.put(TrackEntity.from(track, liked = saved?.liked == true, localPath = file.absolutePath,
            playedAt = saved?.lastPlayedAt ?: 0L))
        return track.copy(localPath = file.absolutePath)
    }

    suspend fun removeDownload(track: Track) {
        downloads.delete(track.id)
        dao.clearDownload(track.id)
    }
}
