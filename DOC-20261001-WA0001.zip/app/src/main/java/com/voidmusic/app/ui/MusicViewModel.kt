package com.voidmusic.app.ui

import android.app.Application
import android.media.audiofx.BassBoost
import androidx.media3.common.Player
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.voidmusic.app.data.AcrCloudRecognizer
import com.voidmusic.app.data.MusicRepository
import com.voidmusic.app.model.RecognizedSong
import com.voidmusic.app.model.Track
import com.voidmusic.app.playback.PlayerController
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MusicViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MusicRepository(application)
    private val recognizer = AcrCloudRecognizer(application)
    private val prefs = application.getSharedPreferences("void-preferences", 0)
    private val gson = Gson()
    private var searchJob: Job? = null
    private var bassBoost: BassBoost? = null
    private var queueTracks: List<Track> = emptyList()

    var tracks = androidx.compose.runtime.mutableStateOf<List<Track>>(emptyList()); private set
    var likedTracks = androidx.compose.runtime.mutableStateOf<List<Track>>(emptyList()); private set
    var recentTracks = androidx.compose.runtime.mutableStateOf<List<Track>>(emptyList()); private set
    var downloadedTracks = androidx.compose.runtime.mutableStateOf<List<Track>>(emptyList()); private set
    var likedIds = androidx.compose.runtime.mutableStateOf<Set<String>>(emptySet()); private set
    var currentTrack = androidx.compose.runtime.mutableStateOf<Track?>(null); private set
    var isPlaying = androidx.compose.runtime.mutableStateOf(false); private set
    var loading = androidx.compose.runtime.mutableStateOf(false); private set
    var error = androidx.compose.runtime.mutableStateOf<String?>(null); private set
    var recognized = androidx.compose.runtime.mutableStateOf<RecognizedSong?>(null); private set
    var recognitionHistory = androidx.compose.runtime.mutableStateOf(readRecognitionHistory()); private set
    var recognizing = androidx.compose.runtime.mutableStateOf(false); private set
    var darkTheme = androidx.compose.runtime.mutableStateOf(prefs.getBoolean("dark_theme", true)); private set
    var bassEnabled = androidx.compose.runtime.mutableStateOf(false); private set
    var playlists = androidx.compose.runtime.mutableStateOf(readPlaylists()); private set
    var searchText = androidx.compose.runtime.mutableStateOf(""); private set

    init {
        viewModelScope.launch {
            repository.liked.collectLatest { rows -> likedTracks.value = rows; likedIds.value = rows.map { it.id }.toSet() }
        }
        viewModelScope.launch { repository.recent.collectLatest { recentTracks.value = it } }
        viewModelScope.launch { repository.downloaded.collectLatest { downloadedTracks.value = it } }
        PlayerController.connect(application) { player ->
            player?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) { isPlaying.value = playing }
                override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                    currentTrack.value = queueTracks.firstOrNull { it.id == mediaItem?.mediaId } ?: currentTrack.value
                }
            })
        }
        loadHome()
    }

    fun loadHome() = load { 
        val historyArtist = (likedTracks.value + recentTracks.value).firstOrNull()?.artist
        val result = repository.search(tags = "chill")
        tracks.value = if (historyArtist.isNullOrBlank()) result else result.sortedByDescending { it.artist.equals(historyArtist, true) }
    }

    fun search(text: String) {
        searchText.value = text
        searchJob?.cancel()
        if (text.isBlank()) { loadHome(); return }
        searchJob = viewModelScope.launch {
            delay(280)
            load { tracks.value = repository.search(query = text) }
        }
    }

    fun browseMood(mood: String) {
        val tags = when (mood.lowercase()) {
            "chill" -> "chill ambient"
            "commute" -> "indie pop"
            "energize" -> "electronic upbeat"
            "feel-good" -> "happy pop"
            "focus" -> "instrumental piano"
            "gaming" -> "electronic soundtrack"
            "party" -> "dance pop"
            "romance" -> "love acoustic"
            "sad" -> "melancholic"
            "sleep" -> "sleep ambient"
            else -> mood.lowercase()
        }
        load { tracks.value = repository.search(tags = tags) }
    }

    private fun load(block: suspend () -> Unit) {
        viewModelScope.launch {
            loading.value = true; error.value = null
            try { block() } catch (e: Exception) { error.value = e.message ?: "Something went wrong." }
            finally { loading.value = false }
        }
    }

    fun toggleLike(track: Track) = viewModelScope.launch { repository.toggleLike(track) }

    fun play(track: Track, queue: List<Track> = tracks.value) {
        val safeQueue = if (queue.isEmpty()) listOf(track) else queue
        queueTracks = safeQueue
        val index = safeQueue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        currentTrack.value = track
        isPlaying.value = true
        PlayerController.play(getApplication(), safeQueue, index)
        viewModelScope.launch { repository.markPlayed(track) }
    }

    fun togglePlayback() { PlayerController.toggle(); isPlaying.value = !isPlaying.value }
    fun next() { PlayerController.next(); isPlaying.value = true }
    fun previous() { PlayerController.previous(); isPlaying.value = true }
    fun shuffle() { PlayerController.setShuffle(!(PlayerController.current()?.shuffleModeEnabled ?: false)) }
    fun repeat() { PlayerController.cycleRepeat() }
    fun seekTo(positionMs: Long) = PlayerController.seek(positionMs)

    fun download(track: Track) = load {
        repository.download(track)
        error.value = "Saved for offline listening"
    }

    fun removeDownload(track: Track) = load { repository.removeDownload(track) }

    fun canRecognize() = recognizer.isConfigured()

    fun recognize(onUnavailable: () -> Unit) {
        if (!recognizer.isConfigured()) { error.value = "Add your ACRCloud host, access key, and secret to local.properties first."; onUnavailable(); return }
        viewModelScope.launch {
            recognizing.value = true; recognized.value = null; error.value = null
            try {
                recognized.value = recognizer.recordAndRecognize() ?: run { error.value = "No match found. Try closer to the music."; null }
                recognized.value?.let { song ->
                    recognitionHistory.value = (listOf(song) + recognitionHistory.value)
                        .distinctBy { "${it.title.lowercase()}|${it.artist.lowercase()}" }.take(12)
                    prefs.edit().putString("recognition_history", gson.toJson(recognitionHistory.value)).apply()
                }
            }
            catch (e: Exception) { error.value = e.message ?: "Recognition failed." }
            finally { recognizing.value = false }
        }
    }

    fun toggleTheme() {
        darkTheme.value = !darkTheme.value
        prefs.edit().putBoolean("dark_theme", darkTheme.value).apply()
    }

    fun toggleBassBoost() {
        val enabled = !bassEnabled.value
        bassEnabled.value = enabled
        runCatching {
            bassBoost?.release()
            bassBoost = BassBoost(0, 0).apply { setStrength(500); this.enabled = enabled }
        }
    }

    private fun readPlaylists(): List<String> = runCatching {
        val raw = prefs.getString("playlists", null) ?: return@runCatching listOf("Moon Garden", "Night Drive")
        gson.fromJson<List<String>>(raw, object : TypeToken<List<String>>() {}.type).ifEmpty { listOf("Moon Garden", "Night Drive") }
    }.getOrDefault(listOf("Moon Garden", "Night Drive"))

    fun createPlaylist(name: String) {
        val clean = name.trim().take(40)
        if (clean.isBlank() || playlists.value.any { it.equals(clean, true) }) return
        playlists.value = playlists.value + clean
        prefs.edit().putString("playlists", gson.toJson(playlists.value)).apply()
    }

    fun addCurrentToPlaylist(name: String) {
        val track = currentTrack.value ?: return
        val key = "playlist_${name.hashCode()}"
        val ids = runCatching {
            val raw = prefs.getString(key, null) ?: "[]"
            gson.fromJson<List<String>>(raw, object : TypeToken<List<String>>() {}.type) ?: emptyList()
        }.getOrDefault(emptyList())
        prefs.edit().putString(key, gson.toJson((ids + track.id).distinct())).apply()
        error.value = "Added to $name"
    }

    private fun readRecognitionHistory(): List<RecognizedSong> = runCatching {
        val raw = prefs.getString("recognition_history", null) ?: return@runCatching emptyList()
        gson.fromJson<List<RecognizedSong>>(raw, object : TypeToken<List<RecognizedSong>>() {}.type) ?: emptyList()
    }.getOrDefault(emptyList())

    fun playRecognized() { recognized.value?.let(::playRecognized) }

    fun playRecognized(song: RecognizedSong) = load {
        val results = repository.search(query = song.title)
        tracks.value = results
        val match = results.firstOrNull { it.title.equals(song.title, true) && it.artist.equals(song.artist, true) }
            ?: results.firstOrNull { it.title.equals(song.title, true) }
            ?: results.firstOrNull()
        if (match == null) error.value = "No Jamendo catalog match is available for this recognized song."
        else play(match, results)
    }

    fun tracksInPlaylist(name: String): List<Track> {
        val key = "playlist_${name.hashCode()}"
        val ids = runCatching {
            gson.fromJson<List<String>>(prefs.getString(key, "[]"), object : TypeToken<List<String>>() {}.type) ?: emptyList()
        }.getOrDefault(emptyList())
        return (likedTracks.value + recentTracks.value + downloadedTracks.value + tracks.value).distinctBy { it.id }.filter { it.id in ids }
    }

    override fun onCleared() {
        bassBoost?.release()
        super.onCleared()
    }
}
