package com.voidmusic.app.model

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val imageUrl: String,
    val streamUrl: String,
    val downloadUrl: String,
    val downloadAllowed: Boolean,
    val licenseName: String,
    val licenseUrl: String,
    val durationSeconds: Int,
    val localPath: String? = null
) {
    val playableUri: String get() = localPath ?: streamUrl
    val canDownload: Boolean get() = downloadAllowed && downloadUrl.isNotBlank()
    val hasFreeLicense: Boolean get() = licenseUrl.contains("creativecommons.org/", ignoreCase = true)
}

data class RecognizedSong(val title: String, val artist: String, val album: String = "", val url: String = "")
