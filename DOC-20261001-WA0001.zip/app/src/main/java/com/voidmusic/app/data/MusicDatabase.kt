package com.voidmusic.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.voidmusic.app.model.Track
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "saved_tracks")
data class TrackEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val imageUrl: String,
    val streamUrl: String,
    val downloadUrl: String,
    val downloadAllowed: Boolean,
    val licenseName: String,
    val licenseUrl: String,
    val durationSeconds: Int,
    val liked: Boolean = false,
    val localPath: String? = null,
    val lastPlayedAt: Long = 0L
) {
    fun toTrack() = Track(id, title, artist, album, imageUrl, streamUrl, downloadUrl,
        downloadAllowed, licenseName, licenseUrl, durationSeconds, localPath)
    companion object {
        fun from(track: Track, liked: Boolean = false, localPath: String? = track.localPath, playedAt: Long = 0L) =
            TrackEntity(track.id, track.title, track.artist, track.album, track.imageUrl, track.streamUrl,
                track.downloadUrl, track.downloadAllowed, track.licenseName, track.licenseUrl,
                track.durationSeconds, liked, localPath, playedAt)
    }
}

@Dao
interface TrackDao {
    @Query("SELECT * FROM saved_tracks WHERE liked = 1 ORDER BY title")
    fun liked(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM saved_tracks WHERE localPath IS NOT NULL ORDER BY title")
    fun downloaded(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM saved_tracks WHERE lastPlayedAt > 0 ORDER BY lastPlayedAt DESC LIMIT 50")
    fun recentlyPlayed(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM saved_tracks WHERE id = :id LIMIT 1")
    suspend fun find(id: String): TrackEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entity: TrackEntity)

    @Query("UPDATE saved_tracks SET liked = :liked WHERE id = :id")
    suspend fun setLiked(id: String, liked: Boolean)

    @Query("UPDATE saved_tracks SET localPath = NULL WHERE id = :id")
    suspend fun clearDownload(id: String)
}

@Database(entities = [TrackEntity::class], version = 1, exportSchema = false)
abstract class MusicDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao
    companion object {
        @Volatile private var instance: MusicDatabase? = null
        fun get(context: Context): MusicDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, MusicDatabase::class.java, "void-music.db")
                .build().also { instance = it }
        }
    }
}
