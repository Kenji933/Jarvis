package com.voidmusic.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val VoidLavender = Color(0xFFD0BCFF)
val VoidLilac = Color(0xFFB69BFA)
val VoidInk = Color(0xFF0D0B12)
val VoidSurface = Color(0xFF191620)
val VoidMuted = Color(0xFF9B95A8)
val VoidGlow = Color(0x665F4A91)

@Composable
fun VoidTheme(dark: Boolean, content: @Composable () -> Unit) {
    val colors = if (dark) darkColorScheme(
        primary = VoidLavender, onPrimary = Color(0xFF2B2144),
        secondary = Color(0xFFC7B4FF), background = VoidInk, onBackground = Color(0xFFF5F0FF),
        surface = VoidSurface, onSurface = Color(0xFFF2ECFA), surfaceVariant = Color(0xFF262230),
        onSurfaceVariant = Color(0xFFC3BDCD), outline = Color(0xFF514B5C)
    ) else lightColorScheme(
        primary = Color(0xFF6750A4), onPrimary = Color.White,
        secondary = Color(0xFF625B71), background = Color(0xFFF8F5FF), onBackground = Color(0xFF1D1A22),
        surface = Color(0xFFFFFFFF), onSurface = Color(0xFF1D1A22), surfaceVariant = Color(0xFFEAE5F2),
        onSurfaceVariant = Color(0xFF4D4657), outline = Color(0xFF797181)
    )
    MaterialTheme(colorScheme = colors, typography = MaterialTheme.typography, content = content)
}
