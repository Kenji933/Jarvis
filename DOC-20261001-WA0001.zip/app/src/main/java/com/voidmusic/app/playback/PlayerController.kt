package com.voidmusic.app.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.C
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.core.content.ContextCompat
import com.google.common.util.concurrent.ListenableFuture
import com.voidmusic.app.model.Track

object PlayerController {
    @Volatile private var controller: MediaController? = null
    @Volatile private var connecting: ListenableFuture<MediaController>? = null
    @Volatile private var pendingQueue: Pair<List<Track>, Int>? = null

    fun connect(context: Context, onReady: (MediaController?) -> Unit = {}) {
        controller?.let { onReady(it); return }
        synchronized(this) {
            controller?.let { onReady(it); return }
            val active = connecting
            if (active != null) {
                active.addListener({ onReady(runCatching { active.get() }.getOrNull()) }, ContextCompat.getMainExecutor(context))
                return
            }
            val token = SessionToken(context, ComponentName(context, MusicPlaybackService::class.java))
            val future = MediaController.Builder(context, token).buildAsync()
            connecting = future
            future.addListener({
                val result = runCatching { future.get() }.getOrNull()
                controller = result
                connecting = null
                result?.let { player -> pendingQueue?.let { (tracks, index) -> setQueue(player, tracks, index); pendingQueue = null } }
                onReady(result)
            }, ContextCompat.getMainExecutor(context))
        }
    }

    fun play(context: Context, tracks: List<Track>, index: Int) {
        connect(context) { player ->
            if (player == null) pendingQueue = tracks to index else setQueue(player, tracks, index)
        }
    }

    private fun setQueue(player: MediaController, tracks: List<Track>, index: Int) {
        val items = tracks.map { track ->
            MediaItem.Builder().setMediaId(track.id).setUri(track.playableUri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(track.title).setArtist(track.artist)
                    .setAlbumTitle(track.album).setArtworkUri(track.imageUrl.takeIf(String::isNotBlank)?.let(Uri::parse)).build())
                .build()
        }
        player.setMediaItems(items, index.coerceIn(items.indices), C.TIME_UNSET)
        player.prepare()
        player.play()
    }

    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seek(positionMs: Long) { controller?.seekTo(positionMs) }
    fun setShuffle(enabled: Boolean) { controller?.shuffleModeEnabled = enabled }
    fun cycleRepeat() { controller?.let { it.repeatMode = (it.repeatMode + 1) % 3 } }
    fun current() = controller
}
