package com.voidmusic.app.data

import com.google.gson.annotations.SerializedName
import com.voidmusic.app.BuildConfig
import com.voidmusic.app.model.Track
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.QueryMap

interface JamendoService {
    @GET("tracks/")
    suspend fun tracks(@QueryMap params: Map<String, String>): JamendoResponse
}

data class JamendoResponse(val headers: JamendoHeaders?, val results: List<JamendoTrack> = emptyList())
data class JamendoHeaders(val status: String?, val code: Int?, val error_message: String?)
data class JamendoLicense(val name: String?, val url: String?)

data class JamendoTrack(
    val id: String?,
    val name: String?,
    @SerializedName("artist_name") val artistName: String?,
    @SerializedName("album_name") val albumName: String?,
    val image: String?,
    val audio: String?,
    val audiodownload: String?,
    @SerializedName("audiodownload_allowed") val downloadAllowed: Boolean?,
    @SerializedName("license_ccurl") val licenseCcUrl: String?,
    val licenses: List<JamendoLicense>?,
    val duration: Int?
) {
    fun toDomain(): Track = Track(
        id = id.orEmpty(), title = name.orEmpty(), artist = artistName.orEmpty(),
        album = albumName.orEmpty(), imageUrl = image.orEmpty(), streamUrl = audio.orEmpty(),
        downloadUrl = audiodownload.orEmpty(), downloadAllowed = downloadAllowed == true,
        licenseName = licenses?.firstOrNull()?.name
            ?: if (licenseCcUrl?.contains("creativecommons.org", ignoreCase = true) == true) "Creative Commons" else "Jamendo license",
        licenseUrl = licenses?.firstOrNull()?.url ?: licenseCcUrl.orEmpty(), durationSeconds = duration ?: 0
    )
}

object JamendoApi {
    val service: JamendoService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.jamendo.com/v3.0/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(JamendoService::class.java)
    }

    fun params(search: String? = null, tags: String? = null, limit: Int = 24) = buildMap {
        put("client_id", BuildConfig.JAMENDO_CLIENT_ID)
        put("format", "json")
        put("limit", limit.coerceIn(1, 200).toString())
        put("include", "licenses")
        put("audioformat", "mp32")
        put("audiodlformat", "mp32")
        put("type", "single albumtrack")
        search?.takeIf(String::isNotBlank)?.let { put("search", it) }
        tags?.takeIf(String::isNotBlank)?.let { put("fuzzytags", it) }
    }
}
