package com.voidmusic.app.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import android.content.Intent
import android.net.Uri
import com.voidmusic.app.model.Track
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

private val moods = listOf("Chill", "Commute", "Energize", "Feel-good", "Focus", "Gaming", "Party", "Romance", "Sad", "Sleep")
private val gradients = listOf(
    listOf(Color(0xFF21162E), Color(0xFF65468E)), listOf(Color(0xFF131D2F), Color(0xFF45597D)),
    listOf(Color(0xFF28162E), Color(0xFF8E4B77)), listOf(Color(0xFF172B2D), Color(0xFF427B72)),
    listOf(Color(0xFF26201B), Color(0xFF80623F)), listOf(Color(0xFF171F33), Color(0xFF514F8C))
)

@Composable
private fun ScrollPage(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 4.dp), content = content)
}

@Composable
private fun SectionTitle(title: String, trailing: String? = null, onTrailing: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (trailing != null) Text(trailing, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge, modifier = Modifier.clickable { onTrailing?.invoke() })
    }
}

@Composable
fun AlbumDisc(track: Track, modifier: Modifier = Modifier) {
    Box(modifier.clip(CircleShape).background(Brush.linearGradient(gradients[(track.id.hashCode().ushr(1) % gradients.size)])), contentAlignment = Alignment.Center) {
        if (track.imageUrl.isNotBlank()) AsyncImage(track.imageUrl, contentDescription = "${track.title} album artwork", modifier = Modifier.fillMaxSize().clip(CircleShape), contentScale = ContentScale.Crop)
        Box(Modifier.size(12.dp).clip(CircleShape).background(Color(0xFF17131F)).border(2.dp, Color(0xFFBFB5CE), CircleShape))
    }
}

@Composable
fun HomeScreen(model: MusicViewModel, onPlay: (Track) -> Unit, onMood: (String) -> Unit) {
    ScrollPage {
        Text("Find your frequency.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, letterSpacing = (-1).sp)
        Text("Sound for the space between moments.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 5.dp, bottom = 14.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            moods.take(6).forEach { mood -> AssistChip(onClick = { onMood(mood) }, label = { Text(mood) }, shape = RoundedCornerShape(18.dp)) }
        }
        SectionTitle("Made for your orbit", "Refresh") { model.loadHome() }
        if (model.error.value != null && model.tracks.value.isEmpty()) SetupCard(model.error.value!!)
        if (model.loading.value && model.tracks.value.isEmpty()) LoadingRow()
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            model.tracks.value.take(5).forEachIndexed { index, track -> HeroCard(track, index, onClick = { onPlay(track) }) }
        }
        SectionTitle("Speed dial")
        val dial = listOf("Chill", "Commute", "Energize", "Focus", "Gaming", "Sleep")
        dial.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEachIndexed { i, mood ->
                    val color = gradients[(i + row.size) % gradients.size]
                    Box(Modifier.weight(1f).height(78.dp).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(color)).clickable { onMood(mood) }.padding(13.dp), contentAlignment = Alignment.BottomStart) {
                        Text(mood.uppercase(), color = Color.White, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(10.dp))
        }
        SectionTitle("A little more you")
        if (model.likedTracks.value.isEmpty() && model.recentTracks.value.isEmpty()) {
            Text("Like a few tracks and your recommendations will find their shape.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(bottom = 18.dp))
        } else {
            val preferred = model.likedTracks.value + model.recentTracks.value
            preferred.distinctBy { it.id }.take(5).forEach { TrackRow(it, model, onPlay, compact = true) }
        }
        if (model.tracks.value.isNotEmpty()) {
            SectionTitle("New discoveries")
            model.tracks.value.drop(5).take(8).forEach { TrackRow(it, model, onPlay) }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun HeroCard(track: Track, index: Int, onClick: () -> Unit) {
    Box(Modifier.width(304.dp).height(225.dp).clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(gradients[index % gradients.size])).clickable { onClick() }) {
        if (track.imageUrl.isNotBlank()) AsyncImage(track.imageUrl, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .82f)))))
        Text(track.title.uppercase(), modifier = Modifier.align(Alignment.CenterStart).padding(start = 16.dp).rotate(-90f), color = Color.White.copy(alpha = .72f), style = MaterialTheme.typography.headlineMedium.copy(drawStyle = Stroke(width = 1.4f)), fontWeight = FontWeight.Black, maxLines = 1)
        Column(Modifier.align(Alignment.BottomStart).padding(17.dp)) {
            Text("YOUR NEXT OBSESSION", color = VoidLavender, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
            Text(track.title, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Color.White.copy(.78f), style = MaterialTheme.typography.bodySmall)
        }
        Surface(Modifier.align(Alignment.BottomEnd).padding(15.dp).size(42.dp), shape = CircleShape, color = VoidLavender.copy(alpha = .95f)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.PlayArrow, "Play ${track.title}", tint = Color(0xFF211835), modifier = Modifier.clickable { onClick() }) }
        }
    }
}

@Composable
fun SearchScreen(model: MusicViewModel, onPlay: (Track) -> Unit, onMood: (String) -> Unit) {
    var tab by remember { mutableStateOf("Explore") }
    ScrollPage {
        Text("Search the sound.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, letterSpacing = (-1).sp)
        Surface(Modifier.fillMaxWidth().padding(top = 16.dp), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Row(Modifier.padding(horizontal = 15.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(10.dp))
                BasicTextField(value = model.searchText.value, onValueChange = model::search, singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                    modifier = Modifier.weight(1f).padding(vertical = 12.dp), decorationBox = { inner ->
                        if (model.searchText.value.isEmpty()) Text("Tracks, artists, moods", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        inner()
                    })
                if (model.searchText.value.isNotEmpty()) Icon(Icons.Filled.Close, "Clear search", Modifier.clickable { model.search("") }, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Explore", "Suggestions", "Artists").forEach { label -> FilterChip(selected = tab == label, onClick = { tab = label }, label = { Text(label) }) }
        }
        if (model.searchText.value.isNotBlank()) {
            SectionTitle("Live results", "${model.tracks.value.size} tracks")
            if (model.loading.value) LoadingRow()
            model.tracks.value.forEach { TrackRow(it, model, onPlay) }
        } else when (tab) {
            "Explore" -> {
                SectionTitle("Moods & moments")
                moods.chunked(2).forEachIndexed { idx, pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { mood ->
                            Box(Modifier.weight(1f).height(96.dp).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(gradients[(idx + mood.length) % gradients.size])).clickable { onMood(mood) }.padding(15.dp), contentAlignment = Alignment.BottomStart) {
                                Text(mood.uppercase(), color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                SectionTitle("Trending in the void")
                model.tracks.value.take(8).forEach { TrackRow(it, model, onPlay) }
            }
            "Suggestions" -> {
                SectionTitle("Picked from your listening")
                val suggestions = (model.likedTracks.value + model.recentTracks.value + model.tracks.value).distinctBy { it.id }
                if (suggestions.isEmpty()) Text("Start listening to shape your suggestions.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                suggestions.take(12).forEach { TrackRow(it, model, onPlay) }
            }
            else -> {
                SectionTitle("Artists to follow")
                val artists = model.tracks.value.map { it.artist }.filter(String::isNotBlank).distinct()
                artists.forEachIndexed { index, artist ->
                    Row(Modifier.fillMaxWidth().clickable { model.search(artist) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(gradients[index % gradients.size])), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Person, null, tint = Color.White) }
                        Column(Modifier.padding(start = 12.dp)) { Text(artist, fontWeight = FontWeight.SemiBold); Text("Jamendo artist", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall) }
                        Spacer(Modifier.weight(1f)); Icon(Icons.Outlined.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .18f))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun RecognizeScreen(model: MusicViewModel, requestRecognition: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "listen-pulse")
    val scale by pulse.animateFloat(.92f, 1.08f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "pulse")
    var showHistory by remember { mutableStateOf(false) }
    ScrollPage {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("Recognize", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black); Text("What’s in the air?", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            IconButton(onClick = { showHistory = !showHistory }) { Icon(Icons.Outlined.History, if (showHistory) "Hide recognition history" else "Show recognition history") }
        }
        Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth().height(330.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(284.dp).scale(scale).clip(CircleShape).border(1.dp, VoidLavender.copy(alpha = .12f), CircleShape))
            Box(Modifier.size(230.dp).clip(CircleShape).background(Brush.radialGradient(listOf(VoidGlow, MaterialTheme.colorScheme.background))).border(1.dp, VoidLavender.copy(alpha = .24f), CircleShape))
            Box(Modifier.size(174.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF342847), Color(0xFF17131F)))).border(1.dp, VoidLavender.copy(alpha = .35f), CircleShape)
                .clickable(enabled = !model.recognizing.value) { requestRecognition() }, contentAlignment = Alignment.Center) {
                if (model.recognizing.value) CircularProgressIndicator(color = VoidLavender, strokeWidth = 2.dp)
                else Icon(Icons.Outlined.GraphicEq, "Tap to listen or hum", tint = VoidLavender, modifier = Modifier.size(60.dp))
            }
            Text(if (model.recognizing.value) "LISTENING" else "TAP TO LISTEN OR HUM", modifier = Modifier.align(Alignment.BottomCenter), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium, letterSpacing = 2.sp)
        }
        Text("Hold your phone near the music, or hum a melody. ACRCloud recognition uses your configured music and cover-song database.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        model.error.value?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 12.dp)) }
        model.recognized.value?.let { match ->
            SectionTitle("The signal is clear")
            Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(gradients[1])), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.MusicNote, null, tint = Color.White) }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(match.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(match.artist, color = MaterialTheme.colorScheme.onSurfaceVariant); if (match.album.isNotBlank()) Text(match.album, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    IconButton(onClick = model::playRecognized) { Icon(Icons.Filled.PlayArrow, "Play match from Jamendo", tint = MaterialTheme.colorScheme.primary) }
                }
            }
        }
        if (showHistory) {
            SectionTitle("Recognition history")
            if (model.recognitionHistory.value.isEmpty()) Text("Songs you recognize will appear here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            model.recognitionHistory.value.forEach { song ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.History, null, tint = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(song.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(song.artist, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { model.playRecognized(song) }) { Icon(Icons.Filled.PlayArrow, "Find and play ${song.title} on Jamendo", tint = MaterialTheme.colorScheme.primary) }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .12f))
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun LibraryScreen(model: MusicViewModel, onPlay: (Track) -> Unit) {
    var tab by remember { mutableStateOf("Playlists") }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    ScrollPage {
        Text("Your library", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Playlists", "Songs", "Albums", "Artists").forEach { FilterChip(selected = tab == it, onClick = { tab = it }, label = { Text(it) }) }
        }
        if (tab == "Playlists") {
            SectionTitle("Collections", "＋ New") { showCreate = true }
            model.playlists.value.chunked(2).forEachIndexed { rowIndex, names ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    names.forEachIndexed { column, name ->
                        PlaylistTile(name, rowIndex * 2 + column, Modifier.weight(1f), model, onPlay)
                    }
                    if (names.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
            }
            SectionTitle("Keep close")
            listOf(
                Triple("Liked", model.likedTracks.value, Icons.Outlined.FavoriteBorder),
                Triple("Downloaded", model.downloadedTracks.value, Icons.Outlined.Download),
                Triple("Recently played", model.recentTracks.value, Icons.Outlined.History),
                Triple("My top 50", model.recentTracks.value.take(50), Icons.Outlined.Equalizer)
            ).forEach { (label, rows, icon) ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { tab = label }.padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(gradients[label.length % gradients.size])), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White) }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(label, fontWeight = FontWeight.SemiBold); Text("${rows.size} tracks", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Icon(Icons.Outlined.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            val rows = when (tab) {
                "Songs" -> (model.likedTracks.value + model.recentTracks.value).distinctBy { it.id }
                "Albums" -> (model.likedTracks.value + model.recentTracks.value).distinctBy { it.album }
                "Artists" -> (model.likedTracks.value + model.recentTracks.value).distinctBy { it.artist }
                "Liked" -> model.likedTracks.value
                "Downloaded" -> model.downloadedTracks.value
                "Recently played", "My top 50" -> model.recentTracks.value
                else -> emptyList()
            }
            SectionTitle(tab)
            if (rows.isEmpty()) Text("Your ${tab.lowercase()} will show up here as you listen.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            rows.forEach { TrackRow(it, model, onPlay, compact = true) }
        }
        Spacer(Modifier.height(12.dp))
    }
    if (showCreate) AlertDialog(
        onDismissRequest = { showCreate = false },
        title = { Text("New playlist") },
        text = { OutlinedTextField(newName, { newName = it }, label = { Text("Name") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { model.createPlaylist(newName); newName = ""; showCreate = false }) { Text("Create") } },
        dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } }
    )
}

@Composable
private fun PlaylistTile(name: String, index: Int, modifier: Modifier, model: MusicViewModel, onPlay: (Track) -> Unit) {
    val items = model.tracksInPlaylist(name)
    Column(modifier.clip(RoundedCornerShape(20.dp)).clickable { items.firstOrNull()?.let(onPlay) }) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(gradients[index % gradients.size]))) {
            val cells = listOf(Alignment.TopStart, Alignment.TopEnd, Alignment.BottomStart, Alignment.BottomEnd)
            cells.forEachIndexed { i, alignment ->
                val color = gradients[(index + i + 1) % gradients.size]
                Box(Modifier.align(alignment).padding(if (alignment == Alignment.TopStart || alignment == Alignment.BottomStart) 8.dp else 8.dp).size(70.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(color))) {
                    items.getOrNull(i)?.imageUrl?.takeIf(String::isNotBlank)?.let { AsyncImage(it, null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                }
            }
            Icon(Icons.Outlined.PlayArrow, "Play playlist", Modifier.align(Alignment.BottomEnd).padding(11.dp).size(36.dp).clip(CircleShape).background(VoidLavender).padding(7.dp), tint = Color(0xFF211835))
        }
        Text(name, modifier = Modifier.padding(top = 9.dp), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${items.size} tracks", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SettingsScreen(model: MusicViewModel) {
    ScrollPage {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        SectionTitle("Appearance")
        SettingRow(Icons.Outlined.DarkMode, "Dark theme", "The night is the default.") { Switch(model.darkTheme.value, { model.toggleTheme() }) }
        SectionTitle("Player & audio")
        SettingRow(Icons.Outlined.Equalizer, "Bass boost", "Local playback effect") { Switch(model.bassEnabled.value, { model.toggleBassBoost() }) }
        SettingRow(Icons.Outlined.Shuffle, "Playback", "Queue, shuffle and repeat are available in the player") { Icon(Icons.Outlined.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        SectionTitle("Storage")
        SettingRow(Icons.Outlined.Download, "Offline tracks", "${model.downloadedTracks.value.size} tracks stored in app data") { Icon(Icons.Outlined.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        SectionTitle("About this signal")
        Text("Void Music streams free-licensed music from Jamendo and displays its artist and license attribution. Tracks are offered for offline download only when Jamendo marks them as downloadable.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(18.dp))
        Text("Void Music · 1.0.0", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, action: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(23.dp))
        Column(Modifier.weight(1f).padding(horizontal = 13.dp)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        action()
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .15f))
}

@Composable
private fun TrackRow(track: Track, model: MusicViewModel, onPlay: (Track) -> Unit, compact: Boolean = false) {
    val context = LocalContext.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onPlay(track) }.padding(vertical = if (compact) 7.dp else 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(if (compact) 47.dp else 54.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(gradients[track.id.hashCode().ushr(1) % gradients.size])), contentAlignment = Alignment.Center) {
            if (track.imageUrl.isNotBlank()) AsyncImage(track.imageUrl, "${track.title} cover", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Outlined.MusicNote, null, tint = Color.White)
        }
        Column(Modifier.weight(1f).padding(horizontal = 11.dp)) {
            Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${track.artist} · ${track.album.ifBlank { "Single" }}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (!compact) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(track.licenseName, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.clickable { track.licenseUrl.takeIf(String::isNotBlank)?.let { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) } })
                    if (track.licenseUrl.isNotBlank()) Text("  ·  License", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        IconButton(onClick = { model.toggleLike(track) }, modifier = Modifier.size(36.dp)) {
            Icon(if (track.id in model.likedIds.value) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                if (track.id in model.likedIds.value) "Unlike ${track.title}" else "Like ${track.title}", tint = if (track.id in model.likedIds.value) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
        }
        if (track.canDownload) {
            val isOffline = track.localPath != null || model.downloadedTracks.value.any { it.id == track.id }
            IconButton(onClick = { if (isOffline) model.removeDownload(track) else model.download(track) }, modifier = Modifier.size(36.dp)) {
                Icon(if (isOffline) Icons.Filled.DownloadDone else Icons.Outlined.Download,
                    if (isOffline) "Remove offline copy of ${track.title}" else "Download ${track.title}",
                    tint = if (isOffline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
            }
        }
    }
    if (!compact) HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .12f))
}

@Composable
private fun SetupCard(message: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Info, null, tint = MaterialTheme.colorScheme.primary)
            Text(message, modifier = Modifier.padding(start = 10.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun LoadingRow() {
    Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.primary)
        Text("Finding your frequency…", Modifier.padding(start = 10.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun PlayerScreen(model: MusicViewModel, onBack: () -> Unit) {
    val track = model.currentTrack.value ?: model.tracks.value.firstOrNull()
    var position by remember { mutableFloatStateOf(0f) }
    var duration by remember { mutableFloatStateOf(1f) }
    var shuffleOn by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(0) }
    var showPlaylist by remember { mutableStateOf(false) }
    LaunchedEffect(track?.id) {
        while (true) {
            val player = com.voidmusic.app.playback.PlayerController.current()
            if (player != null) {
                position = player.currentPosition.coerceAtLeast(0L).toFloat()
                duration = player.duration.takeIf { it > 0L }?.toFloat() ?: (track?.durationSeconds?.coerceAtLeast(1)?.times(1000f) ?: 1f)
                model.isPlaying.value = player.isPlaying
            }
            delay(450)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().padding(top = 9.dp, bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Outlined.KeyboardArrowDown, "Close player", modifier = Modifier.size(30.dp)) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("NOW PLAYING", style = MaterialTheme.typography.labelSmall, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text("VOID RADIO", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp) }
            IconButton(onClick = { showPlaylist = true }) { Icon(Icons.Outlined.MoreVert, "More actions") }
        }
        if (track != null) {
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(320.dp), contentAlignment = Alignment.Center) {
                RadialVisualizer(Modifier.fillMaxSize(), model.isPlaying.value)
                Box(Modifier.size(224.dp).clip(CircleShape).background(Brush.linearGradient(gradients[track.id.hashCode().ushr(1) % gradients.size])).border(1.dp, VoidLavender.copy(alpha = .4f), CircleShape)) {
                    if (track.imageUrl.isNotBlank()) AsyncImage(track.imageUrl, "${track.title} cover", Modifier.fillMaxSize().clip(CircleShape), contentScale = ContentScale.Crop)
                    Box(Modifier.align(Alignment.Center).size(30.dp).clip(CircleShape).background(Color(0xFF15111E)).border(2.dp, VoidLavender.copy(alpha = .8f), CircleShape))
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(track.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track.artist, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { model.toggleLike(track) }) {
                    Icon(if (track.id in model.likedIds.value) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Like track", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                }
                IconButton(onClick = { showPlaylist = true }) { Icon(Icons.Outlined.PlaylistAdd, "Add to playlist", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp)) }
            }
            Text("${track.artist} · ${track.licenseName}", Modifier.fillMaxWidth(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(value = position.coerceIn(0f, duration), onValueChange = { position = it }, onValueChangeFinished = { model.seekTo(position.toLong()) }, valueRange = 0f..duration, modifier = Modifier.padding(top = 13.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(position.toLong()), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(formatTime(duration.toLong()), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { shuffleOn = !shuffleOn; model.shuffle() }) { Icon(Icons.Outlined.Shuffle, "Shuffle", tint = if (shuffleOn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) }
                IconButton(onClick = model::previous) { Icon(Icons.Filled.SkipPrevious, "Previous", modifier = Modifier.size(34.dp)) }
                Surface(Modifier.size(70.dp).clickable { model.togglePlayback() }, shape = CircleShape, color = MaterialTheme.colorScheme.primary, shadowElevation = 12.dp) {
                    Box(contentAlignment = Alignment.Center) { Icon(if (model.isPlaying.value) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play or pause", tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(34.dp)) }
                }
                IconButton(onClick = model::next) { Icon(Icons.Filled.SkipNext, "Next", modifier = Modifier.size(34.dp)) }
                IconButton(onClick = { repeatMode = (repeatMode + 1) % 3; model.repeat() }) { Icon(if (repeatMode == 2) Icons.Outlined.RepeatOne else Icons.Outlined.Repeat, "Repeat", tint = if (repeatMode != 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            Spacer(Modifier.height(22.dp))
            Surface(Modifier.fillMaxWidth().clickable { showPlaylist = true }, shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .72f)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.QueueMusic, null, tint = MaterialTheme.colorScheme.primary)
                    Text("Up next", Modifier.weight(1f).padding(start = 10.dp), fontWeight = FontWeight.SemiBold)
                    Text("${model.tracks.value.size} tracks", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            Spacer(Modifier.height(60.dp)); Text("Choose a track to begin.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(30.dp))
    }
    if (showPlaylist) {
        AlertDialog(onDismissRequest = { showPlaylist = false }, title = { Text("Add to playlist") },
            text = { Column { model.playlists.value.forEach { name -> TextButton(onClick = { model.addCurrentToPlaylist(name); showPlaylist = false }) { Text(name) } } } },
            confirmButton = { TextButton(onClick = { showPlaylist = false }) { Text("Done") } })
    }
}

@Composable
private fun RadialVisualizer(modifier: Modifier, active: Boolean) {
    val transition = rememberInfiniteTransition(label = "radial-eq")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "eq-phase")
    Canvas(modifier) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val base = size.minDimension * .36f
        val count = 52
        for (i in 0 until count) {
            val angle = (i.toFloat() / count) * (2f * Math.PI.toFloat())
            val wave = if (active) .04f + .13f * ((sin(i * .9f + phase * 8) + 1f) / 2f) else .035f
            val inner = base
            val outer = base + size.minDimension * wave
            val start = Offset(center.x + cos(angle) * inner, center.y + sin(angle) * inner)
            val end = Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer)
            drawLine(VoidLavender.copy(alpha = .28f + .52f * (i % 4) / 4f), start, end, strokeWidth = if (i % 3 == 0) 3.dp.toPx() else 1.5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
        }
        drawCircle(VoidLavender.copy(alpha = .08f), radius = base * 1.38f, center = center, style = Stroke(1.dp.toPx()))
    }
}

private fun formatTime(milliseconds: Long): String {
    val seconds = (milliseconds / 1000L).coerceAtLeast(0L)
    return "%d:%02d".format(seconds / 60L, seconds % 60L)
}
