package com.voidmusic.app.data

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.SystemClock
import android.util.Base64
import com.voidmusic.app.BuildConfig
import com.voidmusic.app.model.RecognizedSong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class AcrCloudRecognizer(context: Context) {
    private val appContext = context.applicationContext
    private val client = OkHttpClient.Builder().callTimeout(40, TimeUnit.SECONDS).build()

    fun isConfigured() = BuildConfig.ACRCLOUD_HOST.isNotBlank() &&
        BuildConfig.ACRCLOUD_ACCESS_KEY.isNotBlank() && BuildConfig.ACRCLOUD_ACCESS_SECRET.isNotBlank()

    suspend fun recordAndRecognize(seconds: Int = 8): RecognizedSong? = withContext(Dispatchers.IO) {
        check(isConfigured()) { "Add ACRCloud host, access key, and secret to local.properties first." }
        val sample = File(appContext.cacheDir, "recognize.m4a")
        sample.delete()
        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(appContext) else @Suppress("DEPRECATION") MediaRecorder()
        try {
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setAudioSamplingRate(44100)
            recorder.setAudioEncodingBitRate(96000)
            recorder.setOutputFile(sample.absolutePath)
            recorder.prepare()
            recorder.start()
            delay(seconds * 1_000L)
            recorder.stop()
        } finally {
            runCatching { recorder.reset() }
            recorder.release()
        }
        check(sample.exists() && sample.length() > 0) { "No audio was recorded. Try again in a quieter place." }
        identify(sample)
    }

    private fun identify(sample: File): RecognizedSong? {
        val host = BuildConfig.ACRCLOUD_HOST.trim().removePrefix("https://").removePrefix("http://").trimEnd('/')
        val uri = "/v1/identify"
        val method = "POST"
        val type = "audio"
        val version = "1"
        val timestamp = (System.currentTimeMillis() / 1000L).toString()
        val message = "$method\n$uri\n${BuildConfig.ACRCLOUD_ACCESS_KEY}\n$type\n$version\n$timestamp"
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(BuildConfig.ACRCLOUD_ACCESS_SECRET.toByteArray(Charsets.US_ASCII), "HmacSHA1"))
        val signature = Base64.encodeToString(mac.doFinal(message.toByteArray(Charsets.US_ASCII)), Base64.NO_WRAP)
        val audioBody = sample.asRequestBody("audio/mp4".toMediaType())
        val requestBody = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("sample", sample.name, audioBody)
            .addFormDataPart("sample_bytes", sample.length().toString())
            .addFormDataPart("access_key", BuildConfig.ACRCLOUD_ACCESS_KEY)
            .addFormDataPart("timestamp", timestamp)
            .addFormDataPart("signature", signature)
            .addFormDataPart("data_type", type)
            .addFormDataPart("signature_version", version)
            .build()
        val request = Request.Builder().url("https://$host$uri").post(requestBody).build()
        return client.newCall(request).execute().use { response ->
            check(response.isSuccessful) { "Recognition service returned ${response.code}." }
            val root = JSONObject(response.body?.string().orEmpty())
            val status = root.optJSONObject("status")
            if (status?.optInt("code", -1) != 0) throw IllegalStateException(status?.optString("msg", "No match found. Try recording again."))
            val metadata = root.optJSONObject("metadata") ?: return null
            val item = metadata.optJSONArray("music")?.optJSONObject(0) ?: return null
            val artists = item.optJSONArray("artists")
            val artist = if (artists != null && artists.length() > 0) artists.getJSONObject(0).optString("name") else "Unknown artist"
            val album = item.optJSONObject("album")?.optString("name").orEmpty()
            val external = item.optJSONObject("external_ids")
            val songLink = external?.optJSONObject("youtube")?.optString("vid").orEmpty()
            RecognizedSong(item.optString("title", "Unknown title"), artist, album, songLink)
        }
    }
}
