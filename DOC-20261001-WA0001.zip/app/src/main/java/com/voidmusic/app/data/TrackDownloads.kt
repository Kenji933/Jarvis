package com.voidmusic.app.data

import android.content.Context
import com.voidmusic.app.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

class TrackDownloads(context: Context) {
    private val directory = File(context.filesDir, "offline").apply { mkdirs() }
    private val client = OkHttpClient.Builder().callTimeout(3, TimeUnit.MINUTES).build()

    suspend fun download(track: Track): File = withContext(Dispatchers.IO) {
        require(track.canDownload) {
            "Jamendo does not permit downloading this track."
        }
        val target = File(directory, "${track.id}.mp3")
        val request = Request.Builder().url(track.downloadUrl).build()
        client.newCall(request).execute().use { response ->
            check(response.isSuccessful) { "Download failed (${response.code})." }
            val body = requireNotNull(response.body) { "Empty download response." }
            body.byteStream().use { input -> target.outputStream().use { output -> input.copyTo(output) } }
        }
        target
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        File(directory, "$id.mp3").delete()
    }
}
