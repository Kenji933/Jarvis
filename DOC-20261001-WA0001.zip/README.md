# Void Music

A native Android music player built with **Kotlin, Jetpack Compose, Material 3, Media3 ExoPlayer, Room, and Retrofit**. Void Music uses the official Jamendo v3 API for free-licensed catalog discovery and ACRCloud's official Identification API for recognition. It does not scrape or use unofficial YouTube/Spotify endpoints.

## Requirements

- Android Studio with **JDK 17 or newer**
- Android SDK Platform **35** and Android Build Tools **35.0.0**
- A Jamendo API client ID from the [Jamendo developer portal](https://devportal.jamendo.com/)
- An ACRCloud Audio & Video Recognition project, if you want music recognition. Recognition needs its **host**, **access key**, and **access secret**.

## Setup

1. Open this folder in Android Studio, or install the Android SDK and Java 17+ on your machine.
2. Copy `local.properties.example` to `local.properties` (Android Studio may already create the latter with `sdk.dir`).
3. Fill in the credentials in `local.properties`:

   ```properties
   sdk.dir=/absolute/path/to/Android/Sdk
   JAMENDO_CLIENT_ID=your_jamendo_client_id
   ACRCLOUD_HOST=identify-eu-west-1.acrcloud.com
   ACRCLOUD_ACCESS_KEY=your_acrcloud_access_key
   ACRCLOUD_ACCESS_SECRET=your_acrcloud_access_secret
   ```

   Use the exact `host` shown for your ACRCloud project; its region may differ from the example. Never commit `local.properties`.

4. For humming support, configure the ACRCloud project with the **ACRCloud Music** bucket and **Audio Fingerprinting & Cover Song (humming) Identification** engine. The app records an 8-second clip only after the user taps the recognize control and grants microphone permission. ACRCloud's recognition service/account terms and pricing apply separately; the app itself has no ads or in-app paywall.
5. Sync Gradle and run the app on an Android 8.0/API 26+ device.

## Build

```bash
./gradlew assembleDebug
```

The debug APK is written to:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Run JVM unit tests with:

```bash
./gradlew test
```

To install from a connected device/emulator:

```bash
./gradlew installDebug
```

## Included

- Dark-first near-black/lavender visual design, optional light theme, outlined hero cards, mood chips, three-column speed dial, rounded glass-style floating player/navigation, and vector Material icons.
- Home discovery, live track search, mood browsing, suggestion and artist views, track library, liked songs, recent listening, offline downloads, playlist creation, and settings.
- Full-screen player with a radial visualizer, seek bar, previous/play/next, shuffle, repeat, like, playlist actions, and Media3 background session/notification/lock-screen controls.
- Room persistence for likes, listening history, and downloaded track metadata; offline audio is stored in the app's private files directory.
- Download UI is shown only when Jamendo returns `audiodownload_allowed=true`; tracks show artist and license attribution.
- ACRCloud microphone recognition signed using the provider's documented HMAC-SHA1 Identification API request format.

## Credential and licensing notes

- Jamendo stream and download URLs and the `audiodownload_allowed` flag come from the official Jamendo API; a download is never offered when the flag is false. Attribution is shown from each track's license metadata.
- API keys are read from the untracked `local.properties` file and injected as `BuildConfig` values, not stored in source control. **A secret embedded in a distributable Android APK can still be extracted.** For a production release, put ACRCloud signing/recognition behind a backend you control and issue narrowly scoped credentials; do not treat `BuildConfig` as secret storage.
- Jamendo's access, catalog licenses, and API terms apply. Recognition is provided by ACRCloud and its account limits/pricing apply; Void Music does not add a paywall or ads.
- Official references: [Jamendo Tracks API](https://developer.jamendo.com/v3.0/tracks), [Jamendo API terms](https://devportal.jamendo.com/api_terms_of_use), [ACRCloud Identification API](https://docs.acrcloud.com/reference/identification-api/identification-api), and [ACRCloud humming setup](https://docs.acrcloud.com/get-started/tutorials/recognize-music).

## Project layout

```text
app/src/main/java/com/voidmusic/app/
  data/       Retrofit API, Room database, repository, downloads, ACRCloud client
  model/      Track and recognition models
  playback/   Media3 playback service and controller
  ui/         Compose screens, theme, and state holder
```
